// Puente WhatsApp → ArtMMX Redes.
// Mantiene abierta la sesión de WhatsApp (como WhatsApp Web, escaneando un QR) y pasa los mensajes
// al agente IA que vive en Cloudflare. Las respuestas regresan por aquí.
//
// AVISO: usa una conexión NO oficial (librería Baileys). WhatsApp no la permite en sus reglas y puede
// bloquear el número. Úsalo con un número que no sea vital. La alternativa segura es la API oficial.
"use strict";
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const QRCode = require("qrcode");
const pino = require("pino");
const baileys = require("@whiskeysockets/baileys");
const makeWASocket = baileys.default || baileys.makeWASocket;
const { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = baileys;

const VERSION = "1.0.0";
const DIR = process.env.PUENTE_DIR || __dirname;
const CONFIG = path.join(DIR, "config.json");
const SESION = path.join(DIR, "sesion-whatsapp");
const CADA_MS = Number(process.env.PUENTE_CADA_MS || 5000);

const hora = () => new Date().toLocaleTimeString("es-MX", { hour12: false });
const log = (...a) => console.log(`[${hora()}]`, ...a);
const dormir = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------- configuración
function leerCodigo(codigo) {
  try {
    const o = JSON.parse(Buffer.from(String(codigo).trim(), "base64url").toString("utf8"));
    if (/^https?:\/\//.test(o.u) && typeof o.t === "string" && o.t.length > 20) return { url: o.u.replace(/\/+$/, ""), token: o.t };
  } catch { /* código mal copiado */ }
  return null;
}

async function configuracion() {
  if (process.env.PUENTE_CODIGO) { const c = leerCodigo(process.env.PUENTE_CODIGO); if (c) return c; }
  try { const c = JSON.parse(fs.readFileSync(CONFIG, "utf8")); if (c.url && c.token) return c; } catch { /* no existe aún */ }
  console.log("\n=== Puente WhatsApp · ArtMMX Redes ===");
  console.log("En el panel ve a Cuentas → WhatsApp → Conectar, copia el CÓDIGO DE CONEXIÓN y pégalo aquí");
  console.log("(en esta ventana se pega con clic derecho) y presiona Enter.\n");
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  for (;;) {
    const resp = await new Promise((r) => rl.question("Código: ", r));
    const c = leerCodigo(resp);
    if (c) { rl.close(); fs.writeFileSync(CONFIG, JSON.stringify(c, null, 2)); log("Código guardado."); return c; }
    console.log("Ese código no es válido. Cópialo completo desde el panel e inténtalo otra vez.");
  }
}

let cfg = null;
async function api(method, ruta, body) {
  let r;
  try {
    r = await fetch(cfg.url + ruta, { method, headers: { Authorization: "Bearer " + cfg.token, "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(45000) });
  } catch (e) { log("⚠️  Sin conexión con ArtMMX Redes:", e.message); return null; }
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 || r.status === 410) {
    log("❌", d.error || "El código de conexión ya no es válido.");
    log("   Genera un código nuevo en el panel (Cuentas → WhatsApp) y vuelve a abrir el puente.");
    try { fs.unlinkSync(CONFIG); } catch { /* ya no estaba */ }
    process.exit(2);
  }
  if (!r.ok) { log("⚠️  ArtMMX Redes respondió", r.status, d.error || ""); return null; }
  return d;
}

// ---------------------------------------------------------------- WhatsApp
let sock = null;
let estadoActual = "iniciando";
let numero = "";
const enviadosPorMi = new Set(); // ids de lo que mandó el puente (para no confundirlo con el dueño)
const recordar = (id) => { enviadosPorMi.add(id); if (enviadosPorMi.size > 2000) enviadosPorMi.delete(enviadosPorMi.values().next().value); };

async function reportar(estado, extra = {}) {
  estadoActual = estado;
  await api("POST", "/wa/estado", { estado, numero, version: VERSION, ...extra });
}

const IGNORAR = /(@g\.us|@broadcast|@newsletter)$/;
function contenido(m) {
  let msg = m.message || {};
  for (const k of ["ephemeralMessage", "viewOnceMessage", "viewOnceMessageV2", "documentWithCaptionMessage", "editedMessage"]) if (msg[k]?.message) msg = msg[k].message;
  const texto = msg.conversation || msg.extendedTextMessage?.text || msg.imageMessage?.caption || msg.videoMessage?.caption || msg.documentMessage?.caption
    || msg.buttonsResponseMessage?.selectedDisplayText || msg.listResponseMessage?.title || msg.templateButtonReplyMessage?.selectedDisplayText || "";
  const media = msg.imageMessage ? "foto" : msg.audioMessage ? "audio" : msg.videoMessage ? "video" : msg.documentMessage ? "documento"
    : msg.stickerMessage ? "sticker" : msg.locationMessage || msg.liveLocationMessage ? "ubicación" : msg.contactMessage || msg.contactsArrayMessage ? "contacto" : null;
  return { texto: String(texto || "").trim(), media };
}

async function manejar(m) {
  const chat = m.key?.remoteJid || "";
  if (!chat || chat === "status@broadcast" || IGNORAR.test(chat)) return;
  if (m.key.fromMe && enviadosPorMi.has(m.key.id)) return; // lo mandó el agente
  const { texto, media } = contenido(m);
  if (!texto && !media) return; // reacciones, avisos del sistema, etc.
  const ts = Number(m.messageTimestamp?.low ?? m.messageTimestamp) || Math.floor(Date.now() / 1000);
  log(m.key.fromMe ? "📱 Tú →" : "💬 Llegó de", m.pushName || chat.split("@")[0], ":", (texto || `(${media})`).slice(0, 80));
  const r = await api("POST", "/wa/entrante", { id: m.key.id, chat, nombre: m.pushName || "", texto, media, de_mi: !!m.key.fromMe, ts });
  if (!m.key.fromMe && r?.accion && r.accion !== "pausado") { try { await sock.readMessages([m.key]); } catch { /* no importa */ } }
  if (r?.accion === "humano") log("🙋 El agente pidió ayuda: contesta tú desde el panel o desde tu teléfono.");
  if (r?.salida?.length) await enviar(r.salida);
}

let cadena = Promise.resolve();
function enviar(lista) {
  // en fila, una por una, para no encimar mensajes
  cadena = cadena.then(async () => {
    for (const s of lista) {
      try {
        if (estadoActual !== "conectado" || !sock) throw new Error("WhatsApp no está conectado");
        await sock.sendPresenceUpdate("composing", s.para).catch(() => {});
        await dormir(Math.min(1000 + s.texto.length * 35, 6000)); // "escribiendo..." como una persona
        const enviado = await sock.sendMessage(s.para, { text: s.texto });
        recordar(enviado?.key?.id);
        await sock.sendPresenceUpdate("paused", s.para).catch(() => {});
        await api("POST", "/wa/ack", { id: s.id, ok: true, externo_id: enviado?.key?.id || "" });
        log("✅ Respondido a", s.para.split("@")[0]);
      } catch (e) {
        log("❌ No se pudo enviar a", s.para.split("@")[0], ":", e.message);
        await api("POST", "/wa/ack", { id: s.id, ok: false, error: e.message });
      }
    }
  }).catch(() => {});
  return cadena;
}

async function conectar() {
  const { state, saveCreds } = await useMultiFileAuthState(SESION);
  let version;
  try { ({ version } = await fetchLatestBaileysVersion()); } catch { /* usa la que trae la librería */ }
  sock = makeWASocket({ ...(version ? { version } : {}), auth: state, logger: pino({ level: "silent" }), printQRInTerminal: false, markOnlineOnConnect: false, syncFullHistory: false });
  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      const dataUrl = await QRCode.toDataURL(qr, { margin: 1, width: 320 });
      await reportar("qr", { qr: dataUrl });
      console.log(await QRCode.toString(qr, { type: "terminal", small: true }));
      log("📷 Escanea el QR: en tu teléfono abre WhatsApp → Dispositivos vinculados → Vincular un dispositivo.");
      log("   También aparece en el panel (Cuentas → WhatsApp).");
    }
    if (connection === "open") {
      numero = "+" + String(sock.user?.id || "").split("@")[0].split(":")[0];
      await reportar("conectado");
      log("✅ WhatsApp conectado:", numero, "— el agente ya puede contestar. Deja esta ventana abierta.");
    }
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      const salio = code === DisconnectReason.loggedOut;
      await reportar("desconectado");
      if (salio) {
        log("🔒 Se cerró la sesión desde el teléfono. Borro la sesión guardada y genero un QR nuevo.");
        fs.rmSync(SESION, { recursive: true, force: true });
      } else log("🔌 Conexión perdida (código", code, "). Reconectando en 5 segundos…");
      setTimeout(() => conectar().catch((e) => log("Error al reconectar:", e.message)), salio ? 1500 : 5000);
    }
  });
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    for (const m of messages) {
      // "notify" = mensaje nuevo. Lo que escribes desde tu teléfono a veces llega como "append": solo se toma si es reciente.
      if (type !== "notify") { const ts = Number(m.messageTimestamp?.low ?? m.messageTimestamp) || 0; if (!m.key?.fromMe || Date.now() / 1000 - ts > 120) continue; }
      try { await manejar(m); } catch (e) { log("Error con un mensaje:", e.message); }
    }
  });
}

async function revisarSalida() {
  for (;;) {
    await dormir(CADA_MS);
    if (estadoActual !== "conectado") continue;
    const d = await api("GET", "/wa/salida");
    if (d?.salida?.length) await enviar(d.salida);
  }
}
async function latido() {
  for (;;) { await dormir(60000); await api("POST", "/wa/estado", { estado: estadoActual, numero, version: VERSION }); }
}

(async () => {
  console.log(`Puente WhatsApp · ArtMMX Redes v${VERSION}`);
  cfg = await configuracion();
  log("Conectando con", cfg.url);
  if (!(await api("POST", "/wa/estado", { estado: "iniciando", version: VERSION }))) log("⚠️  No pude hablar con ArtMMX Redes; sigo intentando.");
  await conectar();
  revisarSalida();
  latido();
})().catch((e) => { console.error("Error grave:", e); process.exit(1); });
