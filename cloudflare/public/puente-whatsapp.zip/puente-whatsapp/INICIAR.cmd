@echo off
chcp 65001 >nul
title Puente WhatsApp - ArtMMX Redes
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Falta Node.js. Instalalo desde https://nodejs.org ^(version LTS^) y vuelve a abrir este archivo.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Instalando por primera vez. Tarda uno o dos minutos...
  call npm install --omit=dev --no-audit --no-fund
  if errorlevel 1 (
    echo No se pudo instalar. Revisa tu internet y vuelve a intentarlo.
    pause
    exit /b 1
  )
)
:otra_vez
node puente.js
if errorlevel 2 (
  echo.
  echo Pega el codigo nuevo cuando lo pida.
)
echo.
echo El puente se detuvo. Se vuelve a abrir en 10 segundos. Para apagarlo, cierra esta ventana.
timeout /t 10 >nul
goto otra_vez
