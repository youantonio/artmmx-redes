@echo off
chcp 65001 >nul
set "DEST=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\puente-whatsapp-artmmx.cmd"
> "%DEST%" echo @echo off
>> "%DEST%" echo start "Puente WhatsApp" /min "%~dp0INICIAR.cmd"
echo Listo: el puente se abrira solo cada vez que prendas la compu.
echo Para quitarlo, borra este archivo:
echo %DEST%
pause
